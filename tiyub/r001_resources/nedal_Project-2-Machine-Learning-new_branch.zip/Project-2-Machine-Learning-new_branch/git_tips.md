# git tips  

Create branch and checkout in 1 command:  
git checkout -b [branch name: overwrites this including brackets]  <br /><br />

Deleting local branches in Git:  
$ git branch -d [branch name: overwrites this including brackets]  <br /><br />

Deleting remote branches in Git:  
$ git push origin --delete [branch name: overwrites this including brackets]  <br /><br />

A very good straight forward tutorial geting a local branch 'commiting' on a remote repository:
[freecodecamp.org](https://www.freecodecamp.org/news/git-and-github-for-beginners/)  
> Making a working/project directory and being in that working/project directory when you run git init makes everything run 'better'